const mysql = require('mysql2');

const connection = mysql.createConnection({
    host : 'localhost',
    user: 'root',
    password:'',
    port: 3307,
    database : 'alexsandro'
});

 connection.connect();
console.log("conectado")
 
 
 let query = "update usuario set senha = 254322 where codigo = 5;";
 connection.query(query, function(error, results, fields){
    console.log("Concluida a alteração ");

 })
 connection.end();